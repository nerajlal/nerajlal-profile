<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Job Application Form</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f7f7f7;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
        }

        .form-container {
            background: #ffffff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            max-width: 400px;
            width: 90%;
        }

        h2 {
            margin-bottom: 15px;
            text-align: center;
            color: #333;
        }

        label {
            display: block;
            margin: 10px 0 5px;
            color: #555;
            font-weight: bold;
        }

        input, select {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }

        button {
            width: 100%;
            padding: 10px;
            background: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background: #0056b3;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <form id="jobApplicationForm">
            <h2>Job Application</h2>
            
            <label for="company_name">Company Name:</label>
            <input type="text" id="company_name" name="company_name" required>

            <label for="position">Position:</label>
            <select id="position" name="position" required>
                <option value="Full Stack Developer - Java">Full Stack Developer - Java</option>
                <option value="Software Engineer">Software Engineer</option>
                <option value="Frontend Developer">Frontend Developer</option>
                <option value="Backend Developer">Backend Developer</option>
                <option value="PHP Developer">PHP Developer</option>
                <option value="Java Developer">Java Developer</option>
                <option value="Web Developer">Web Developer</option>
            </select>

            <label for="hr_email">HR Email:</label>
            <input type="email" id="hr_email" name="hr_email" required>

            <button type="button" onclick="sendApplication()">Open in Gmail</button>
        </form>
    </div>

    <script>
        async function sendApplication() {
            const companyName = document.getElementById('company_name').value;
            const position = document.getElementById('position').value;
            const hrEmail = document.getElementById('hr_email').value;

            // Default values
            const applicantName = "Neraj Lal S";
            const phone = "+91 8547470675";
            const email = "nerajnerajlal@gmail.com";

            const subject = `Application for ${position} position`;
            const body = `Dear Hiring Team at ${companyName},\n\n` +
                        `I am excited to apply for the ${position} position at your esteemed organization. ` +
                        `With a solid foundation and combined with a keen understanding of front-end and back-end development, I am eager to contribute to ${companyName}'s innovative projects.\n` +
                        `My hands-on experience includes creating dynamic web applications and working collaboratively in team environments. ` +
                        `I am confident that my technical skills and enthusiasm for learning will enable me to excel in this role.\n\n` +
                        `I look forward to the opportunity to discuss how my skills and aspirations align with your team's goals.\n` +
                        `I have attached my resume for your review and would welcome the opportunity to discuss how my skills and experiences align with your team’s goals.\n\nThank you for considering my application, and I look forward to the possibility of contributing to ${companyName}’s success.\n` +
                        `Best regards,\n` +
                        `${applicantName}\n` +
                        `Phone: ${phone}\n` +
                        `Email: ${email}`;

            try {
                const gmailUrl = `https://mail.google.com/mail/?view=cm&fs=1&to=${encodeURIComponent(hrEmail)}` +
                               `&su=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
                window.open(gmailUrl, '_blank');
            } catch (error) {
                console.error('Error sending application:', error);
            }
        }
    </script>
</body>
</html>
