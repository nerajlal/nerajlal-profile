<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';

// CSV File Path
$csvFile = 'Phase2_Infopark_Sheet1.csv';
$resumeFile = 'resume.pdf'; // Change this to your actual resume file

// SMTP Configuration
$mailHost = 'smtp.example.com'; // Change to your SMTP host
$mailUsername = 'your-email@example.com';
$mailPassword = 'your-email-password';
$mailFrom = 'your-email@example.com';
$mailFromName = 'Your Name';

function sendJobApplication($hrEmail, $company, $jobRole, $resumeFile) {
    global $mailHost, $mailUsername, $mailPassword, $mailFrom, $mailFromName;

    $mail = new PHPMailer(true);

    try {
        // SMTP Setup
        $mail->isSMTP();
        $mail->Host = $mailHost;
        $mail->SMTPAuth = true;
        $mail->Username = $mailUsername;
        $mail->Password = $mailPassword;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        // Sender & Recipient
        $mail->setFrom($mailFrom, $mailFromName);
        $mail->addAddress($hrEmail);

        // Attach Resume
        $mail->addAttachment($resumeFile);

        // Email Content
        $mail->isHTML(true);
        $mail->Subject = "Application for $jobRole at $company";
        $mail->Body = "
            <p>Dear Hiring Manager,</p>
            <p>I am writing to express my interest in the <strong>$jobRole</strong> position at <strong>$company</strong>.</p>
            <p>Attached is my resume for your consideration.</p>
            <p>Looking forward to the opportunity to discuss further.</p>
            <p>Best regards,<br>Your Name<br>Your Contact</p>
        ";

        // Send Email
        $mail->send();
        echo "Application sent to $hrEmail for $jobRole at $company.\n";
    } catch (Exception $e) {
        echo "Failed to send email to $hrEmail: {$mail->ErrorInfo}\n";
    }
}

// Read CSV and Send Emails
if (($handle = fopen($csvFile, "r")) !== FALSE) {
    fgetcsv($handle); // Skip header row
    while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
        $hrEmail = trim($data[0]);  // Assuming first column is HR email
        $company = trim($data[1]);  // Assuming second column is company name
        $jobRole = trim($data[2]);  // Assuming third column is job role

        if (filter_var($hrEmail, FILTER_VALIDATE_EMAIL)) {
            sendJobApplication($hrEmail, $company, $jobRole, $resumeFile);
        } else {
            echo "Invalid email: $hrEmail\n";
        }
    }
    fclose($handle);
} else {
    echo "Failed to open CSV file.\n";
}
?>
